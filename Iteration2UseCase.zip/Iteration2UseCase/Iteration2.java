public class Iteration2
{
	public static void main(String[] args)
	{
		Window game = new Window();
	}
}
