import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.math.*;
import java.util.*;
/**
 * Write a description of class GameBoard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GameBoard extends JFrame implements ActionListener
{
    // instance variables - replace the example below with your own
    private JPanel topPanel, bottomPanel, topRightPanel, bottomRightPanel;
    private GridButton [][] gridButtons;
    private GridButton [][] pieceStorage;
    private JButton leftButton, resetButton, flipButton, rightButton;
    private int tileNo, orient, player;

    /**
     * Constructor for objects of class GameBoard
     */
    public GameBoard()
    {
        // initialise instance variables
        tileNo = 0;
        orient = 0;
        player = 0;
        topPanel = new JPanel();
        bottomPanel = new JPanel();
        topRightPanel = new JPanel();
        bottomRightPanel = new JPanel();
        bottomPanel.setPreferredSize(new Dimension(400, 70));
        topPanel.setPreferredSize(new Dimension(400, 300));
        topPanel.setLayout( new GridLayout( 20, 20));
        gridButtons = new GridButton [20][20];
        for ( int column = 0; column < 20; column ++)
            {
                for ( int row = 0; row < 20; row ++)
        {
            gridButtons [column][row] = new GridButton( column,row);
            //gridButtons [column][row].setSize( 50, 50);
            gridButtons [column][row].setOpaque( true);
            
            gridButtons [column][row].addActionListener( this);
            topPanel.add( gridButtons [column][row]);
        }
            }
        
        bottomPanel.setPreferredSize(new Dimension(400, 70));
        bottomPanel.setLayout( new GridLayout( 7, 10));
        pieceStorage = new GridButton [7][10];
        for ( int column = 0; column < 7; column ++)
            {
                for ( int row = 0; row < 10; row ++)
        {
            pieceStorage [column][row] = new GridButton( column,row);
            //gridButtons [column][row].setSize( 50, 50);
            pieceStorage [column][row].setOpaque( true);
            pieceStorage [column][row].setEnabled( false);
            pieceStorage [column][row].addActionListener( this);
            bottomPanel.add( pieceStorage [column][row]);
        }
            }
            
            bottomRightPanel.setLayout( new FlowLayout());
        
        leftButton = new JButton("Left");
        leftButton.addActionListener( this);
        resetButton = new JButton("Reset");
        resetButton.addActionListener( this);
        flipButton = new JButton("Flip");
        flipButton.addActionListener( this);
        rightButton = new JButton("Right");
        rightButton.addActionListener( this);
        
        bottomRightPanel.add( leftButton);
        bottomRightPanel.add( resetButton);
        bottomRightPanel.add( flipButton);
        bottomRightPanel.add( rightButton);
        
        /**topRightPanel.setLayout( new GridLayout( 5, 5));
        gridButtons = new GridButton [5][5];
        for ( int column = 0; column < 5; column ++)
            {
                for ( int row = 0; row < 5; row ++)
        {
            gridButtons [column][row] = new GridButton( column,row);
            //gridButtons [column][row].setSize( 50, 50);
            gridButtons [column][row].setOpaque( true);
            
            gridButtons [column][row].addActionListener( this);
            topPanel.add( gridButtons [column][row]);
        }
            }
            setVisible(true);
        updateOri();*/
        
        pieceStorage[1][1].setColour();
        pieceStorage[1][1].setEnabled( true);
        pieceStorage[1][1].setTileNum( 2);
        pieceStorage[2][1].setColour();
        pieceStorage[2][1].setEnabled( true);
        pieceStorage[2][1].setTileNum( 2);
        pieceStorage[3][1].setColour();
        pieceStorage[3][1].setEnabled( true);
        pieceStorage[3][1].setTileNum( 2);
        pieceStorage[4][1].setColour();
        pieceStorage[4][1].setEnabled( true);
        pieceStorage[4][1].setTileNum( 2);
        pieceStorage[5][1].setColour();
        pieceStorage[5][1].setEnabled( true);
        pieceStorage[5][1].setTileNum( 2);
        
        /**pieceStorage[1][3].setColour();
        pieceStorage[1][3].setEnabled( true);
        pieceStorage[1][3].setTileNum( 1);
        pieceStorage[1][4].setColour();
        pieceStorage[1][4].setEnabled( true);
        pieceStorage[1][4].setTileNum( 1);
        pieceStorage[2][4].setColour();
        pieceStorage[2][4].setEnabled( true);
        pieceStorage[2][4].setTileNum( 1);
        pieceStorage[3][4].setColour();
        pieceStorage[3][4].setEnabled( true);
        pieceStorage[3][4].setTileNum( 1);
        pieceStorage[2][5].setColour();
        pieceStorage[2][5].setEnabled( true);
        pieceStorage[2][5].setTileNum( 1);
        
        pieceStorage[1][7].setColour();
        pieceStorage[1][7].setEnabled( true);
        pieceStorage[1][7].setTileNum( 3);
        pieceStorage[2][7].setColour();
        pieceStorage[2][7].setEnabled( true);
        pieceStorage[2][7].setTileNum( 3);
        pieceStorage[1][8].setColour();
        pieceStorage[1][8].setEnabled( true);
        pieceStorage[1][8].setTileNum( 3);
        pieceStorage[2][8].setColour();
        pieceStorage[2][8].setEnabled( true);
        pieceStorage[2][8].setTileNum( 3);
        pieceStorage[3][8].setColour();
        pieceStorage[3][8].setEnabled( true);
        pieceStorage[3][8].setTileNum( 3);*/
            
        getContentPane().setLayout( new BorderLayout());
        getContentPane().add( topPanel, BorderLayout.NORTH);
        getContentPane().add( bottomPanel, BorderLayout.SOUTH);
        getContentPane().add( topRightPanel, BorderLayout.WEST);
        getContentPane().add( bottomRightPanel, BorderLayout.EAST);
        pack();
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        setResizable( true);
        setVisible( true);    
    }
    
    public void updateOri()
    {
        /**int ori = gridButtons [0][0].getOrientation();
        
        if (ori == 1)
            {
                gridButtons [0][0].setColour();
        gridButtons [0][1].setColour();
        gridButtons [1][1].setColour();
        gridButtons [2][1].setColour();
        gridButtons [1][2].setColour();
            }
            else if (ori == 2)
            {
                gridButtons [0][1].setColour();
        gridButtons [1][0].setColour();
        gridButtons [1][1].setColour();
        gridButtons [2][0].setColour();
        gridButtons [1][2].setColour();
            }
            else if (ori == 3)
            {
                gridButtons [1][0].setColour();
        gridButtons [0][1].setColour();
        gridButtons [1][1].setColour();
        gridButtons [2][1].setColour();
        gridButtons [2][2].setColour();
            }
            else if (ori == 4)
            {
                gridButtons [0][2].setColour();
        gridButtons [1][0].setColour();
        gridButtons [1][1].setColour();
        gridButtons [2][1].setColour();
        gridButtons [1][2].setColour();
            }
            else if (ori == 5)
            {
                gridButtons [0][2].setColour();
        gridButtons [0][1].setColour();
        gridButtons [1][1].setColour();
        gridButtons [1][0].setColour();
        gridButtons [2][1].setColour();
            }
            else if (ori == 6)
            {
                gridButtons [0][0].setColour();
        gridButtons [1][0].setColour();
        gridButtons [1][1].setColour();
        gridButtons [2][1].setColour();
        gridButtons [1][2].setColour();
            }
            else if (ori == 7)
            {
                gridButtons [2][0].setColour();
        gridButtons [0][1].setColour();
        gridButtons [1][1].setColour();
        gridButtons [2][1].setColour();
        gridButtons [1][2].setColour();
            }
            else if (ori == 8)
            {
                gridButtons [2][2].setColour();
        gridButtons [0][1].setColour();
        gridButtons [1][1].setColour();
        gridButtons [1][0].setColour();
        gridButtons [1][2].setColour();
            }*/
    }

    public void actionPerformed (ActionEvent aevt)
    {
        Object selected = aevt.getSource();
        
        if(selected.equals(pieceStorage))
            {
            tileNo = pieceStorage[1][1].getTileNum();
            orient=pieceStorage[1][1].getOrientation();
            player=pieceStorage[1][1].getPlayerNum();
        }
        if(selected.equals(gridButtons))
        {
            //int xStore= selected.getXCoord;
            
        }
    }
}
