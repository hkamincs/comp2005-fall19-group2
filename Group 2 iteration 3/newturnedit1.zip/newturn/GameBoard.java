 
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.math.*;
import java.util.*;
/**
 * Write a description of class GameBoard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GameBoard extends JFrame implements ActionListener
{
    // instance variables - replace the example below with your own
    private JPanel topPanel, bottomPanel, topRightPanel, bottomRightPanel;
    private GridButton [][] gridButtons;
    private GridButton [][] pieceStorage;
    private JButton ConfirmButton, saveButton; //leftButton, resetButton, flipButton, rightButton; 
    private int tileNo, orient, player;

    /**
     * Constructor for objects of class GameBoard
     */
    public GameBoard()
    {
        // initialise instance variables
        tileNo = 0;
        orient = 0;
        player = 0;
        topPanel = new JPanel();
        bottomPanel = new JPanel();
        topRightPanel = new JPanel();
        bottomRightPanel = new JPanel();
        bottomPanel.setPreferredSize(new Dimension(400, 70));
        topPanel.setPreferredSize(new Dimension(400, 300));
        topPanel.setLayout( new GridLayout( 20, 20));
        gridButtons = new GridButton [20][20];
        for ( int column = 0; column < 20; column ++)
            {
                for ( int row = 0; row < 20; row ++)
        {
            gridButtons [column][row] = new GridButton( column,row);
            //gridButtons [column][row].setSize( 50, 50);
            gridButtons [column][row].setOpaque( true);
            
            gridButtons [column][row].addActionListener( this);
            topPanel.add( gridButtons [column][row]);
        }
            }
        
        bottomPanel.setPreferredSize(new Dimension(400, 70));
        bottomPanel.setLayout( new GridLayout( 7, 10));
        ConfirmButton = new JButton("comfirm");
        ConfirmButton.addActionListener(this);
        saveButton = new JButton("Save");
        saveButton.addActionListener(this);
        bottomRightPanel.add(ConfirmButton);
        bottomRightPanel.add(saveButton);
        pieceStorage = new GridButton [7][10];
        for ( int column = 0; column < 7; column ++)
            {
                for ( int row = 0; row < 10; row ++)
                {
                	pieceStorage [column][row] = new GridButton( column,row);
                	//gridButtons [column][row].setSize( 50, 50);
                	pieceStorage [column][row].setOpaque( true);
                	pieceStorage [column][row].setEnabled( false);
                	pieceStorage [column][row].addActionListener( this);
                	bottomPanel.add( pieceStorage [column][row]);
                }
            }
            //bottomRightPanel.setLayout( new FlowLayout());
       // leftButton = new JButton("Left");
        //leftButton.addActionListener( this);
       // resetButton = new JButton("Reset");
        //resetButton.addActionListener( this);
        //flipButton = new JButton("Flip");
        //flipButton.addActionListener( this);
        //rightButton = new JButton("Right");
        //rightButton.addActionListener( this);
       // bottomRightPanel.add( leftButton);
       // bottomRightPanel.add( resetButton);
       // bottomRightPanel.add( flipButton);
       // bottomRightPanel.add( rightButton);
        
        /*topRightPanel.setLayout( new GridLayout( 5, 5));
        gridButtons = new GridButton [5][5];
        for ( int column = 0; column < 5; column ++)
            {
                for ( int row = 0; row < 5; row ++)
        {
            gridButtons [column][row] = new GridButton( column,row);
            //gridButtons [column][row].setSize( 50, 50);
            gridButtons [column][row].setOpaque( true);
            
            gridButtons [column][row].addActionListener( this);
            topPanel.add( gridButtons [column][row]);
        }
            }
            setVisible(true);
        updateOri();*/
        
       /* pieceStorage[1][1].setColour();
        pieceStorage[1][1].setEnabled( true);
        pieceStorage[1][1].setTileNum( 2);
        pieceStorage[2][1].setColour();
        pieceStorage[2][1].setEnabled( true);
        pieceStorage[2][1].setTileNum( 2);
        pieceStorage[3][1].setColour();
        pieceStorage[3][1].setEnabled( true);
        pieceStorage[3][1].setTileNum( 2);
        pieceStorage[4][1].setColour();
        pieceStorage[4][1].setEnabled( true);
        pieceStorage[4][1].setTileNum( 2);
        pieceStorage[5][1].setColour();
        pieceStorage[5][1].setEnabled( true);
        pieceStorage[5][1].setTileNum( 2);*/
        
        pieceStorage[1][3].setColour();
        pieceStorage[1][3].setEnabled( true);
        pieceStorage[1][3].setTileNum( 1);
        pieceStorage[1][4].setColour();
        pieceStorage[1][4].setEnabled( true);
        pieceStorage[1][4].setTileNum( 1);
        pieceStorage[2][4].setColour();
        pieceStorage[2][4].setEnabled( true);
        pieceStorage[2][4].setTileNum( 1);
        pieceStorage[3][4].setColour();
        pieceStorage[3][4].setEnabled( true);
        pieceStorage[3][4].setTileNum( 1);
        pieceStorage[2][5].setColour();
        pieceStorage[2][5].setEnabled( true);
        pieceStorage[2][5].setTileNum( 1);
        
      /*  pieceStorage[1][7].setColour();
        pieceStorage[1][7].setEnabled( true);
        pieceStorage[1][7].setTileNum( 3);
        pieceStorage[2][7].setColour();
        pieceStorage[2][7].setEnabled( true);
        pieceStorage[2][7].setTileNum( 3);
        pieceStorage[1][8].setColour();
        pieceStorage[1][8].setEnabled( true);
        pieceStorage[1][8].setTileNum( 3);
        pieceStorage[2][8].setColour();
        pieceStorage[2][8].setEnabled( true);
        pieceStorage[2][8].setTileNum( 3);
        pieceStorage[3][8].setColour();
        pieceStorage[3][8].setEnabled( true);
        pieceStorage[3][8].setTileNum( 3);*/
            
        getContentPane().setLayout( new BorderLayout());
        getContentPane().add( topPanel, BorderLayout.NORTH);
        getContentPane().add( bottomPanel, BorderLayout.SOUTH);
        getContentPane().add( topRightPanel, BorderLayout.WEST);
        getContentPane().add( bottomRightPanel, BorderLayout.EAST);
        pack();
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        setResizable( true);
        setVisible( true);
    }
    public void usingBufferedWriter() throws IOException
     {
         BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\User\\Owner\\Documents\\Comp 2005\\test.txt"));
            for (int a = 0; a<20;a++)
        {
        	for (int b = 0;b<20;b++)
        	{
        	    String info = gridButtons[a][b].getXCoord() + " " + gridButtons[a][b].getYCoord() + " " + gridButtons[a][b].getOrientation() + " " + gridButtons[a][b].getTileNum() + " " + gridButtons[a][b].getPlayerNum();
            writer.write(info);
        }
    }
}

    
    public void actionPerformed (ActionEvent aevt)
    {
        Object selected = aevt.getSource();
        for (int a = 0; a < 7; a++)
        {
        	for (int b = 0; b < 10; b++)
        	{
        		if(selected.equals(pieceStorage[a][b]))
            		{
        			tileNo = pieceStorage[a][b].getTileNum();
        			orient=pieceStorage[a][b].getOrientation();
        			GameScreen frame = new GameScreen();
            		}
        	}
        }
        for (int a = 0; a<20;a++)
        {
        	for (int b = 0;b<20;b++)
        	{
        		if(selected.equals(gridButtons[a][b]))
        		{
        			 for(int p = 0; p<GameScreen.arr.length; p++)
        			 {
        				 int A = GameScreen.arr[p][0];
        	        	 int B = GameScreen.arr[p][1];
        				gridButtons[A+a][B+b].setColour();
        		        	 }
        		          }
        			 }
        			 
        			
        		}
        if(selected.equals(saveButton))
        {
           try{
            usingBufferedWriter();
        }
        catch(IOException ex)
        {
            System.out.println("Could not find file");
        }
        }
        	}
        
        
    }

      

