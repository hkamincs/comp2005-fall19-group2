import java.awt.Color;
import javax.swing.*;

public class GridSquare4 extends JButton
{
	public int a, b, xcoord, ycoord;	
	private Color orange, forange, cyan, fcyan;	

	public GridSquare4( int a, int b, int xcoord, int ycoord)
	{
		super();
		this.a = a;
		this.b = b;
		this.xcoord = xcoord;
		this.ycoord = ycoord;
	}
}
