import java.awt.Color;
import javax.swing.*;

public class GridSquare2 extends JButton
{
	public int xcoord, ycoord,state;	
	private Color orange, forange, cyan, fcyan;	

	public GridSquare2( int xcoord, int ycoord)
	{
		super();
		this.xcoord = xcoord;
		this.ycoord = ycoord;
		this.state = 1;
	}
}
