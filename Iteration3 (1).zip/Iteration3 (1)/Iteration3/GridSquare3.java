import java.awt.Color;
import javax.swing.*;

public class GridSquare3 extends JButton
{
	public int a, xcoord, ycoord;	
	private Color orange, forange, cyan, fcyan;	

	public GridSquare3( int a, int xcoord, int ycoord)
	{
		super();
		this.a = a;
		this.xcoord = xcoord;
		this.ycoord = ycoord;
	}
}
