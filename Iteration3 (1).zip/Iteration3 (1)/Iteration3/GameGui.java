import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class GameGui extends JFrame implements ActionListener{
	private JPanel players, playArea, bankArea, centrePanel, sidePanel;
	private JPanel[][] flipPanel;
	private JPanel[] playerPanel;
	private GridSquare2[][] gameBoard;
	private GridSquare2[][] piece;
	//GridSquare2[][] flipWindow;
	private JButton pass;
	private JLabel turnDisplay;
	private JLabel[] pName, pScore;
	public static final int SHAPE_SIZE = 5;
	public static final int PIECE = 1;
	public static final int BLANK = 0;
	private int[][] grid;
	int [][][] shapes = new int[2][5][5];
	
	
	public GameGui(){
		this.setSize(1000,600);
		players = new JPanel();
		playArea = new JPanel();
		bankArea = new JPanel();
		centrePanel = new JPanel();
		sidePanel = new JPanel();
		flipPanel = new JPanel[7][3];
		playerPanel = new JPanel[4];
		gameBoard = new GridSquare2[20][20];
		//flipWindow = new GridSquare2[7][3];
		piece = new GridSquare2[5][5];
		pass = new JButton("Pass");
		turnDisplay = new JLabel("Current Player: Player 1");
		pName = new JLabel[4];
		pScore = new JLabel[4];
		shapes[0] = new int[][] {
			{0, 0, 0, 0, 0},
	        {0, 0, 0, 0, 0},
	        {1, 1, 1, 1, 1},
	        {0, 0, 0, 0, 0},
	        {0, 0, 0, 0, 0}
		};
		shapes[1] = new int[][] {
			{0, 0, 0, 0, 0}, 		//   *
	        {0, 1, 1, 1, 1},
	        {0, 1, 0, 0, 0},
	        {0, 0, 0, 0, 0},
	        {0, 0, 0, 0, 0}
		};
		
		for (int i = 0; i < 2; i++)
		{
			grid = shapes[i];
		}
		players.setLayout(new FlowLayout());
		for (int i=0;i<4;i++){
			playerPanel[i] = new JPanel();
			playerPanel[i].setLayout(new BoxLayout(playerPanel[i],BoxLayout.Y_AXIS));
			pName[i] = new JLabel("Player "+String.valueOf(i+1));
			playerPanel[i].add(pName[i]);
			pScore[i] = new JLabel("Score: "+String.valueOf(93));
			playerPanel[i].add(pScore[i]);
			players.add(playerPanel[i]);
		}
		playArea.setLayout(new GridLayout( 20, 20));
		for (int column = 0; column < 20; column++){
			for (int row = 0; row < 20; row++){
				gameBoard[column][row] = new GridSquare2(column,row);								
				gameBoard[column][row].addActionListener( this);					
				playArea.add( gameBoard[column][row]);		
			}
		}
		centrePanel.setLayout(new BoxLayout(centrePanel,BoxLayout.Y_AXIS));
		centrePanel.add(playArea);
		centrePanel.add(turnDisplay);
		sidePanel.setLayout(new BoxLayout(sidePanel,BoxLayout.Y_AXIS));
		sidePanel.add(bankArea);
		pass.addActionListener( this);
		sidePanel.add(pass);
		//flipPanel.setLayout(new GridLayout(5,5));
		for (int a = 0; a < 7; a++)
		{
			for (int b = 0; b < 3; b++)
			{
				flipPanel[a][b].setLayout(new GridLayout(5,5));
				for (int x = 0; x < 5; x++)
				{
					for (int y = 0; y < 5; y++)
					{
						piece[x][y] = new GridSquare2(x, y);
						if (shapes[1][x][y] == 1)
						{
							piece[x][y].setBackground(Color.red);
						}
						else
						{
							piece[x][y].setBackground(null);
						}
						flipPanel[a][b].add(piece[x][y]);
						sidePanel.add(flipPanel[a][b]);
					}
				}
				//flipWindow[a][b] = new GridSquare2(a, b);
				//flipWindow[a][b] = piece;
			}
		}
	      /*for (int a = 0; a < 7; a++)
	      {
	    	  for (int b = 0; b < 3; b++)
	    	  {
	    		  for (int x = 0; x < 5; x++)
	    	      {
	    	         for (int y = 0; y < 5; y++)
	    	         {
	    	            if (shapes[1][x][y] == 1)
	    	            {
	    	            	flipWindow[a][b][x][y] = new GridSquare4(a,b,x,y);
	    	            	flipWindow[a][b][x][y].setBackground(Color.red);
	    	            }
	    	            else
	    	            {
	    	            	flipWindow[a][b][x][y] = new GridSquare4(a,b,x,y);
		    	            flipWindow[a][b][x][y].setBackground(null);
	    	            }
	    	            flipPanel.add( flipWindow[a][b][x][y]);
	    	         }
	    	      }
	    	  }
	      }*/
		//sidePanel.add(flipPanel);
		
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(players, BorderLayout.NORTH);
		getContentPane().add(centrePanel, BorderLayout.CENTER);
		getContentPane().add(sidePanel, BorderLayout.EAST);		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
		pack();
	}
	
	public void actionPerformed (ActionEvent aevt){
		Object selected = aevt.getSource();
	}
	public static int[][][] getAllShapes()
	   {
	      int[][][] shapes = new int[2][SHAPE_SIZE][SHAPE_SIZE];
	      int i = 0;
	      
	      shapes[i++] = new int[][] { // * * * * *
	         {0, 0, 0, 0, 0},
	         {0, 0, 0, 0, 0},
	         {1, 1, 1, 1, 1},
	         {0, 0, 0, 0, 0},
	         {0, 0, 0, 0, 0}
	      };
	      
	      shapes[i++] = new int[][] { // * * * *
	         {0, 0, 0, 0, 0}, 		//   *
	         {0, 1, 1, 1, 1},
	         {0, 1, 0, 0, 0},
	         {0, 0, 0, 0, 0},
	         {0, 0, 0, 0, 0}
	      };
	      
	      /*shapes[i++] = new int[][] { //   * * *
	         {1, 2, 1, 0, 0},   	  // * *
	         {0, 0, 2, 3, 2},
	         {0, 0, 2, 3, 2},
	         {0, 0, 2, 3, 3},
	         {0, 0, 1, 2, 3}
	      };
	      
	      shapes[i++] = new int[][] { //   *
	         {0, 0, 0, 0, 0}, 		// * * * *
	         {0, 0, 1, 2, 1},
	         {0, 1, 2, 3, 2},
	         {0, 2, 3, 3, 3},
	         {0, 1, 2, 2, 2}
	      };
	      
	      shapes[i++] = new int[][] { //   *
	         {0, 0, 0, 0, 0}, 		// * * *
	         {0, 0, 1, 2, 1}, 		//   *
	         {0, 1, 2, 3, 2},
	         {0, 2, 3, 3, 3},
	         {0, 1, 2, 2, 3}
	      };
	      
	      shapes[i++] = new int[][] { // *
	         {0, 0, 0, 0, 0}, 		// * * *
	         {0, 0, 1, 2, 1}, 		//   *
	         {0, 1, 2, 3, 2},
	         {0, 2, 3, 3, 3},
	         {0, 1, 2, 3, 2}
	      };
	      
	      shapes[i++] = new int[][] { // * * *
	         {0, 0, 0, 0, 0, 0, 0},   // *   *
	         {0, 0, 0, 0, 0, 0, 0},
	         {0, 1, 2, 2, 2, 1, 0},
	         {0, 2, 3, 3, 3, 2, 0},
	         {0, 2, 3, 2, 3, 2, 0}
	      };
	      
	      shapes[i++] = new int[][] { // * *
	         {0, 0, 0, 0, 0, 0, 0}, // * * *
	         {0, 0, 0, 0, 0, 0, 0},
	         {0, 1, 2, 2, 2, 1, 0},
	         {0, 2, 3, 3, 3, 2, 0},
	         {0, 1, 2, 3, 3, 2, 0}
	      };
	      
	      shapes[i++] = new int[][] { //   *
	         {0, 0, 0, 0, 0, 0, 0}, //   * *
	         {0, 0, 0, 1, 2, 1, 0}, // * *
	         {0, 0, 1, 2, 3, 2, 0},
	         {0, 1, 2, 3, 3, 2, 0},
	         {0, 2, 3, 3, 2, 1, 0}
	      };
	      
	      shapes[i++] = new int[][] { // *
	         {0, 0, 0, 0, 0, 0, 0},   // * * *
	         {0, 0, 1, 2, 1, 0, 0},   // *
	         {0, 0, 2, 3, 2, 0, 0},
	         {0, 1, 2, 3, 2, 1, 0},
	         {0, 2, 3, 3, 3, 2, 0}
	      };
	      
	      shapes[i++] = new int[][] { // *
	         {0, 0, 1, 2, 1, 0, 0},   // *
	         {0, 0, 2, 3, 2, 0, 0},   // * * *
	         {0, 0, 2, 3, 2, 2, 1},
	         {0, 0, 2, 3, 3, 3, 2},
	         {0, 0, 1, 2, 2, 2, 1}
	      };
	      
	      shapes[i++] = new int[][] { // *
	         {0, 0, 0, 0, 0, 0, 0},   // * * *
	         {0, 0, 1, 2, 2, 1, 0},   //     *
	         {0, 0, 2, 3, 3, 2, 0},
	         {0, 1, 2, 3, 2, 1, 0},
	         {0, 2, 3, 3, 2, 0, 0}
	      };
	      
	      
	      shapes[i++] = new int[][] { // * * * *
	         {0, 0, 1, 2, 1, 0, 0},   // 
	         {0, 0, 2, 3, 2, 0, 0},
	         {0, 0, 2, 3, 2, 0, 0},
	         {0, 0, 2, 3, 2, 0, 0},
	         {0, 0, 2, 3, 2, 0, 0}
	      };
	      
	      shapes[i++] = new int[][] { // * *
	         {0, 0, 0, 0, 0, 0, 0},   //   * *
	         {0, 0, 1, 2, 2, 1, 0},
	         {0, 1, 2, 3, 3, 2, 0},
	         {0, 2, 3, 3, 2, 1, 0},
	         {0, 1, 2, 2, 1, 0, 0}
	      };
	      
	      shapes[i++] = new int[][] { // * *
	         {0, 0, 0, 0, 0, 0, 0}, //   * *
	         {0, 1, 2, 2, 1, 0, 0},
	         {0, 2, 3, 3, 2, 0, 0},
	         {0, 2, 3, 3, 2, 0, 0},
	         {0, 1, 2, 2, 1, 0, 0}
	      };
	      
	      shapes[i++] = new int[][] { // *
	         {0, 0, 0, 0, 0, 0, 0}, // * * *
	         {0, 0, 1, 2, 1, 0, 0},
	         {0, 1, 2, 3, 2, 1, 0},
	         {0, 2, 3, 3, 3, 2, 0},
	         {0, 1, 2, 2, 2, 1, 0}
	      };
	      
	      shapes[i++] = new int[][] { //   *
	         {0, 0, 0, 0, 0, 0, 0}, // * * *
	         {0, 0, 0, 0, 0, 0, 0},
	         {0, 1, 2, 2, 2, 2, 0},
	         {0, 2, 3, 3, 3, 2, 0},
	         {0, 1, 2, 2, 3, 2, 0}
	      };
	      
	      shapes[i++] = new int[][] { // 
	         {0, 0, 0, 0, 0, 0, 0},   // * * *
	         {0, 0, 0, 0, 0, 0, 0},
	         {0, 1, 2, 2, 2, 1, 0},
	         {0, 2, 3, 3, 3, 2, 0},
	         {0, 1, 2, 2, 2, 1, 0}
	      };
	      
	      shapes[i++] = new int[][] { // *
	         {0, 0, 0, 0, 0, 0, 0},   // * *
	         {0, 0, 1, 2, 1, 0, 0},
	         {0, 0, 2, 3, 2, 1, 0},
	         {0, 0, 2, 3, 3, 2, 0},
	         {0, 0, 1, 2, 2, 1, 0}
	      };
	      
	      shapes[i++] = new int[][] { // * *
	         {0, 0, 0, 0, 0, 0, 0},   // 
	         {0, 0, 1, 2, 1, 0, 0},
	         {0, 0, 2, 3, 2, 0, 0},
	         {0, 0, 2, 3, 2, 0, 0},
	         {0, 0, 1, 2, 1, 0, 0}
	      };
	      
	      shapes[i++] = new int[][] { // *
	         {0, 0, 0, 0, 0, 0, 0},   // 
	         {0, 0, 0, 0, 0, 0, 0},
	         {0, 0, 1, 2, 1, 0, 0},
	         {0, 0, 2, 3, 2, 0, 0},
	         {0, 0, 1, 2, 1, 0, 0}
	      };*/
	      
	      return shapes;
	   }
}

