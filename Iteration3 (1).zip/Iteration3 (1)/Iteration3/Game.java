import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

@SuppressWarnings("unchecked")
public class Game{
	private int[] pColour, cDiff;
	private int pCount, turn, shared3p;
	private	String[] pName;
	private String SName;
	private boolean cBMode;
	
	public Game(){
		
		
	}	
}
