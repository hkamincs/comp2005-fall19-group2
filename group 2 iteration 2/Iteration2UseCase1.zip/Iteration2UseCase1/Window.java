//CS2005 Group 2
//Iteration 2
//Use Case 1 for player/cpu selection and difficulty selection.
//coded by Chris Stacey 201451739

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

@SuppressWarnings("unchecked")
public class Window extends JFrame implements ActionListener{
	private JPanel topPanel, bottomPanel, centrePanel;
	private JPanel[] pSel, pSelMiddlePanel, pSelPlayerType;	
	public JLabel[] pSelNameLabel, pSelColourLabel, pSelCpuLabel, pSelLabel;
	private JLabel topLabel;
	private JRadioButton playerCou2, playerCou3, playerCou4;
	private JRadioButton[] pSelTypeHuman, pSelTypeCpu;		
	public JComboBox[] pSelCpuDif, pSelColour;
	private String[] colourOptions, colourOptions2P, difficulty;
	private TextField[] pSelName;
	
	public Window(){
		
		this.setSize(1000,600);
		topPanel = new JPanel();
		topPanel.setLayout( new FlowLayout());		
		centrePanel = new JPanel();
		centrePanel.setLayout(new FlowLayout());
				
		topLabel = new JLabel("# of players:");
		playerCou2 = new JRadioButton("2");
		playerCou3 = new JRadioButton("3");
		playerCou4 = new JRadioButton("4",true);
		
		colourOptions = new String[]{"Random","Blue","Yellow","Red","Green"};
		colourOptions2P = new String[]{"Random","Blue/Red","Yellow/Green"};
		difficulty = new String[]{"Easy","Medium","Hard"};
		
		pSelName = new TextField[4];
		
		topPanel.add(topLabel);
		topPanel.add(playerCou2);
		topPanel.add(playerCou3);
		topPanel.add(playerCou4);
		playerCou2.addActionListener(this);
		playerCou3.addActionListener(this);
		playerCou4.addActionListener(this);
		pSel = new JPanel[4];
		pSelMiddlePanel = new JPanel[4];
		pSelPlayerType = new JPanel[4];
		pSelLabel = new JLabel[4];
		pSelNameLabel = new JLabel[4];
		pSelColourLabel = new JLabel[4];
		pSelCpuLabel = new JLabel[4];
		pSelCpuDif= new JComboBox[4];
		pSelColour = new JComboBox[4];
		pSelTypeHuman = new JRadioButton[4];
		pSelTypeCpu = new JRadioButton[4];

		for(int i=0;i<4;i++){
			pSelNameLabel[i] = new JLabel("Name:");
			pSelColourLabel[i] = new JLabel("Colour:");
			pSelCpuLabel[i] = new JLabel("Difficulty:");
			pSel[i] = new JPanel();
			pSelMiddlePanel[i] = new JPanel();
			pSelPlayerType[i] = new JPanel();
			pSelLabel[i] = new JLabel("Player "+String.valueOf(i+1));
			pSelColour[i]= new JComboBox(colourOptions);
			pSelTypeHuman[i] = new JRadioButton("Human", true);
			//pSelTypeHuman[i].setEnabled(false);
			pSelTypeCpu[i] = new JRadioButton("CPU");
			pSelTypeHuman[i].addActionListener(this);
			pSelTypeCpu[i].addActionListener(this);
			pSelColour[i].addActionListener(this);
			pSelCpuDif[i]= new JComboBox(difficulty);
			pSelName[i] = new TextField("Player "+String.valueOf(i+1),10);
			pSelPlayerType[i].setLayout(new FlowLayout());
			pSelMiddlePanel[i].setLayout(new BoxLayout(pSelMiddlePanel[i],BoxLayout.Y_AXIS));
			pSel[i].setLayout(new BoxLayout(pSel[i],BoxLayout.Y_AXIS));
			pSel[i].add(pSelLabel[i]);
			pSelPlayerType[i].add(pSelTypeHuman[i]);
			pSelPlayerType[i].add(pSelTypeCpu[i]);
			pSel[i].add(pSelPlayerType[i]);
			pSelMiddlePanel[i].add(pSelNameLabel[i]);
			pSelMiddlePanel[i].add(pSelName[i]);
			pSel[i].add(pSelMiddlePanel[i]);
			pSel[i].add(pSelColourLabel[i]);
			pSel[i].add(pSelColour[i]);
		}
	
		centrePanel.add(pSel[0]);
		centrePanel.add(pSel[1]);
		centrePanel.add(pSel[2]);
		centrePanel.add(pSel[3]);
		
		//pScore.setBackground(orange);
		
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel, BorderLayout.NORTH);
		getContentPane().add(centrePanel, BorderLayout.CENTER);			
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}
	
	public void actionPerformed (ActionEvent aevt){		
		Object selected = aevt.getSource();
		Color cyan = new Color(0,240,240);
		Color red = new Color(255,0,0);
		if ( selected instanceof JRadioButton){
			int HumanIn = Arrays.asList(pSelTypeHuman).indexOf(selected);
			int CpuIn = Arrays.asList(pSelTypeCpu).indexOf(selected);
			if(HumanIn !=-1){
				if(pSelTypeHuman[HumanIn].isSelected()){
					pSelTypeCpu[HumanIn].setSelected(false);
					pSelMiddlePanel[HumanIn].removeAll();
					
					pSelMiddlePanel[HumanIn].add(pSelNameLabel[HumanIn]);
					pSelMiddlePanel[HumanIn].add(pSelName[HumanIn]);
					pSelName[HumanIn].setText("Player "+String.valueOf(HumanIn+1));
					
					pSelMiddlePanel[HumanIn].validate();
				}
				else pSelTypeHuman[HumanIn].setSelected(true);
			}
			if(CpuIn != -1){
				if(pSelTypeCpu[CpuIn].isSelected()){
					pSelTypeHuman[CpuIn].setSelected(false);
					pSelMiddlePanel[CpuIn].removeAll();
					
					pSelMiddlePanel[CpuIn].add(pSelCpuLabel[CpuIn]);
					pSelMiddlePanel[CpuIn].add(pSelCpuDif[CpuIn]);
					
					pSelCpuDif[CpuIn].setSelectedIndex(1);
					pSelMiddlePanel[CpuIn].validate();
					
				}
				else pSelTypeCpu[CpuIn].setSelected(true);
			}
		}
		if ( selected.equals(playerCou2)){
			if(playerCou2.isSelected()){
				playerCou3.setSelected(false);
				playerCou4.setSelected(false);
				centrePanel.removeAll();
				centrePanel.add(pSel[0]);
				centrePanel.add(pSel[1]);
				centrePanel.validate();
				
			}
			else playerCou2.setSelected(true);
		}
		if ( selected.equals(playerCou3)){
			if(playerCou3.isSelected()){
				playerCou2.setSelected(false);
				playerCou4.setSelected(false);
				centrePanel.removeAll();
				centrePanel.add(pSel[0]);
				centrePanel.add(pSel[1]);
				centrePanel.add(pSel[2]);
				centrePanel.validate();
				
			}
			else playerCou3.setSelected(true);
		}
		if ( selected.equals(playerCou4)){
			if(playerCou4.isSelected()){
				playerCou2.setSelected(false);
				playerCou3.setSelected(false);
				centrePanel.removeAll();
				centrePanel.add(pSel[0]);
				centrePanel.add(pSel[1]);
				centrePanel.add(pSel[2]);
				centrePanel.add(pSel[3]);
				centrePanel.validate();
			}
			else playerCou4.setSelected(true);
		}		
		
		if ( selected.equals(pSelColour[0])) {}
		
	}	
}
