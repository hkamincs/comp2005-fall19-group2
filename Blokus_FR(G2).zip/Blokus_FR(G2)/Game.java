import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

@SuppressWarnings("unchecked")
public class Game{
	private int[][] board;
	private int[] turnOrder, diff, pColour;
	private int pCount, turn, shared3p;
	private	String[] pName;
	private String SName;
	private boolean cBMode;
	
	public Game(String gName, String[] players, int[] dif, int[] cOrder, boolean cB){
		turnOrder = new int[] {0,1,2,3};
		pColour = cOrder;
		board = new int[21][4];
		pCount = players.length;
		turn = 0;
		//shared3p = 3;
		diff = dif;
		pName = players;
		SName = gName;
		cBMode = cB;		
	}	
	public Game(String fileName){
		try{
			SName = fileName;
			turnOrder = new int[4];
			diff = new int[4];
			pColour = new int[4];pName = new String[pCount];
			board = new int[21][4];
			File file = new File("Save\\"+fileName+".txt");
			Scanner scanner = new Scanner(file);
			pCount = Integer.parseInt(scanner.next());
			pColour = new int[4];
			pName = new String[pCount];
			cBMode = false;
			if(scanner.next()=="1")
			cBMode = true;
			turn=Integer.parseInt(scanner.next());
			int next = Integer.parseInt(scanner.next());
			for(int i=0;i<pCount;i++){
				turnOrder[i] = next;
				pColour[i] = Integer.parseInt(scanner.next());
				pName[i] = scanner.next();
				next = Integer.parseInt(scanner.next());
				int partCount = 0;
				while(next>4){
					board[partCount][0]=next;
					board[partCount][1]=Integer.parseInt(scanner.next());
					board[partCount][2]=Integer.parseInt(scanner.next());
					board[partCount][3]=Integer.parseInt(scanner.next());
					next = Integer.parseInt(scanner.next());
				}
			}
		
			scanner.close();
		}
		catch(IOException ex){
			System.out.println(ex.toString());
			System.out.println("File not found: "+fileName+".txt");
		}
	}
}
