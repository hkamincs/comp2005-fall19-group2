import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

@SuppressWarnings("unchecked")
public class GameGui extends JFrame implements ActionListener{
	private JPanel players, playArea, bankArea, centrePanel, sidePanel, flipPanel,flipButton;
	private JPanel[] playerPanel;
	private GridSquare2[][] gameBoard, flipWindow;
	private GridSquare2[][][] playerBank;
	private JButton pass, rotC, rotCC, flipHor, flipVer, save;
	private JButton[] pView;
	private JLabel turnDisplay;
	private JLabel[] pName, pScore;
	private Color red;
	
	public GameGui(Game game){
		this.setSize(1000,600);
		players = new JPanel();
		playArea = new JPanel();
		bankArea = new JPanel();
		centrePanel = new JPanel();
		sidePanel = new JPanel();
		flipPanel = new JPanel();
		flipButton = new JPanel();
		playerPanel = new JPanel[4];
		gameBoard = new GridSquare2[20][20];
		flipWindow = new GridSquare2[5][5];
		playerBank = new GridSquare2[4][15][11];
		pass = new JButton("Pass");
		rotC = new JButton("CW");
		rotCC = new JButton("CCW");
		flipHor = new JButton("Hor");
		flipVer = new JButton("Ver");
		save = new JButton("Save");
		pView = new JButton[4];
		turnDisplay = new JLabel("Current Player: Player 1");
		pName = new JLabel[4];
		pScore = new JLabel[4];
		red = new Color(255,0,0);
		
		int[][] bankLayout = {{1,1,0,0,1,1,1,1,0,1,1},{1,1,0,1,0,1,0,0,1,0,1},{0,0,1,1,0,0,0,1,1,0,1},{1,0,1,0,1,1,0,0,1,0,1},
			 {1,1,0,1,1,0,1,1,0,1,0},{0,1,1,0,1,0,1,0,1,1,1},{1,0,0,1,0,1,0,1,0,1,0},{1,0,1,1,0,1,1,1,0,0,1},{1,0,1,0,0,0,0,0,0,0,1},
			 {1,0,1,0,1,1,1,0,1,0,1},{1,0,0,1,0,0,1,0,1,0,1},{0,1,1,1,0,0,1,0,1,0,0},{0,1,0,0,0,1,0,1,0,1,1},{1,0,0,1,1,1,0,1,0,1,1},
		     {1,0,1,0,0,0,1,1,1,0,1}};
		
		players.setLayout(new FlowLayout());
		for (int i=0;i<4;i++){
			playerPanel[i] = new JPanel();
			playerPanel[i].setLayout(new BoxLayout(playerPanel[i],BoxLayout.Y_AXIS));
			pName[i] = new JLabel("Player "+String.valueOf(i+1));
			playerPanel[i].add(pName[i]);
			pScore[i] = new JLabel("Score: "+String.valueOf(93));
			playerPanel[i].add(pScore[i]);
			pView[i] = new JButton("View Bank");
			playerPanel[i].add(pView[i]);
			players.add(playerPanel[i]);
		}
		playArea.setLayout(new GridLayout( 20, 20));
		for (int column = 0; column < 20; column++){
			for (int row = 0; row < 20; row++){
				gameBoard[column][row] = new GridSquare2(column,row);								
				gameBoard[column][row].addActionListener( this);					
				playArea.add( gameBoard[column][row]);		
			}
		}
		centrePanel.setLayout(new BoxLayout(centrePanel,BoxLayout.Y_AXIS));
		centrePanel.add(playArea);
		centrePanel.add(turnDisplay);
		bankArea.setLayout(new GridLayout(15,11));
		for (int i=0;i<4;i++){
			for (int column = 0; column < 15; column++){
				for (int row = 0; row < 11; row++){
					playerBank[i][column][row] = new GridSquare2(column,row);				
					playerBank[i][column][row].state = bankLayout[column][row];
					if (bankLayout[column][row] != 0)
						playerBank[i][column][row].setBackground(red);
					playerBank[i][column][row].addActionListener( this);					
					if(i==0)
						bankArea.add(playerBank[i][column][row]);
				}
			}
		}
		sidePanel.setLayout(new BoxLayout(sidePanel,BoxLayout.Y_AXIS));
		sidePanel.add(bankArea);
		sidePanel.add(pass);
		flipPanel.setLayout(new GridLayout(5,5));
		for (int column = 0; column < 5; column++){
			for (int row = 0; row < 5; row++){
				flipWindow[column][row] = new GridSquare2(column,row);					
				flipPanel.add( flipWindow[column][row]);		
			}
		}
		sidePanel.add(flipPanel);
		flipButton.setLayout(new FlowLayout());
		flipButton.add(rotC);
		flipButton.add(rotCC);
		flipButton.add(flipHor);
		flipButton.add(flipVer);
		sidePanel.add(flipButton);
		sidePanel.add(save);
		
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(players, BorderLayout.NORTH);
		getContentPane().add(centrePanel, BorderLayout.CENTER);
		getContentPane().add(sidePanel, BorderLayout.EAST);		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
		
		
		
		
		
		
	}
	
	public void actionPerformed (ActionEvent aevt){		
		Object selected = aevt.getSource();
		
		
	}	
}
