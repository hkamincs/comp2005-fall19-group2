import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

@SuppressWarnings("unchecked")
public class SetupGame extends JFrame implements ActionListener{
	private JPanel topPanel, bottomPanel, centrePanel;
	private JPanel[] pSel, pSelMiddlePanel, pSelPlayerType;	
	public JLabel[] pSelNameLabel, pSelColourLabel, pSelCpuLabel, pSelLabel;
	private JLabel topLabel, cBlind, saveLabel,errorMessage;
	
	private JRadioButton[] pSelTypeHuman, pSelTypeCpu;		
	public JComboBox[] pSelCpuDif, pSelColour;
	public JComboBox pAmount;
	private String[] colourOptions, colourOptions2P, difficulty, playerAmount;
	private TextField[] pSelName;
	public TextField saveName;
	public JRadioButton cBlindMode;
	public JButton startGame;
	
	public SetupGame(){
		this.setSize(1000,600);
		
		colourOptions = new String[]{"Random","Blue","Yellow","Red","Green"};
		colourOptions2P = new String[]{"Random","Blue/Red","Yellow/Green"};
		difficulty = new String[]{"Easy","Medium","Hard"};
		playerAmount = new String[]{"2","3","4"};
		File folder = new File("Save");
		File[] listOfFiles = folder.listFiles();
		String[] saveNames = new String[listOfFiles.length+1];
		for (int i=0;i<listOfFiles.length;i++){
			String fileName = listOfFiles[i].getName();
			saveNames[i+1] = fileName.substring(0,fileName.length()-4);
		}
		int nameCount = 1;
		String defaultName = "Game1";
		boolean validName = false;
		while(!validName){
			validName = true;
			
			defaultName = "Game"+String.valueOf(nameCount);
			for(int i=1;i<saveNames.length;i++){
				//System.out.println(defaultName+" "+saveNames[i]);
				if(saveNames[i].equals(defaultName)){
					//System.out.println("false");
					validName = false;
					nameCount++;
				}
			}
		}	
		
		topLabel = new JLabel("# of players:");
		cBlind = new JLabel("Colour Blind Mode: ");
		saveLabel = new JLabel("Save File Name: ");
		errorMessage = new JLabel("press start when ready");
		pAmount = new JComboBox(playerAmount);
		pAmount.setSelectedIndex(2);
		pAmount.addActionListener(this);
		saveName = new TextField(defaultName);
		JRadioButton cBlindMode = new JRadioButton();
		startGame = new JButton("Start");
		
		
		topPanel = new JPanel();
		topPanel.setLayout( new FlowLayout());		
		centrePanel = new JPanel();
		bottomPanel = new JPanel();
		centrePanel.setLayout(new FlowLayout());
		bottomPanel.setLayout(new BoxLayout(bottomPanel,BoxLayout.Y_AXIS));
		topPanel.add(saveLabel);
		topPanel.add(saveName);
		topPanel.add(topLabel);
		topPanel.add(pAmount);
		topPanel.add(cBlind);
		topPanel.add(cBlindMode);
		bottomPanel.add(errorMessage);
		bottomPanel.add(startGame);
		
		pSelName = new TextField[4];
		pSel = new JPanel[4];
		pSelMiddlePanel = new JPanel[4];
		pSelPlayerType = new JPanel[4];
		pSelLabel = new JLabel[4];
		pSelNameLabel = new JLabel[4];
		pSelColourLabel = new JLabel[4];
		pSelCpuLabel = new JLabel[4];
		pSelCpuDif= new JComboBox[4];
		pSelColour = new JComboBox[4];
		pSelTypeHuman = new JRadioButton[4];
		pSelTypeCpu = new JRadioButton[4];
		startGame.addActionListener(this);

		for(int i=0;i<4;i++){
			pSelNameLabel[i] = new JLabel("Name:");
			pSelColourLabel[i] = new JLabel("Colour:");
			pSelCpuLabel[i] = new JLabel("Difficulty:");
			pSel[i] = new JPanel();
			pSelMiddlePanel[i] = new JPanel();
			pSelPlayerType[i] = new JPanel();
			pSelLabel[i] = new JLabel("Player "+String.valueOf(i+1));
			pSelColour[i]= new JComboBox(colourOptions);
			pSelTypeHuman[i] = new JRadioButton("Human", true);
			
			pSelTypeCpu[i] = new JRadioButton("CPU");
			pSelTypeHuman[i].addActionListener(this);
			pSelTypeCpu[i].addActionListener(this);
			pSelColour[i].addActionListener(this);
			
			pSelCpuDif[i]= new JComboBox(difficulty);
			pSelName[i] = new TextField("Player"+String.valueOf(i+1),10);
			pSelPlayerType[i].setLayout(new FlowLayout());
			pSelMiddlePanel[i].setLayout(new BoxLayout(pSelMiddlePanel[i],BoxLayout.Y_AXIS));
			pSel[i].setLayout(new BoxLayout(pSel[i],BoxLayout.Y_AXIS));
			pSel[i].add(pSelLabel[i]);
			pSelPlayerType[i].add(pSelTypeHuman[i]);
			pSelPlayerType[i].add(pSelTypeCpu[i]);
			pSel[i].add(pSelPlayerType[i]);
			pSelMiddlePanel[i].add(pSelNameLabel[i]);
			pSelMiddlePanel[i].add(pSelName[i]);
			pSel[i].add(pSelMiddlePanel[i]);
			pSel[i].add(pSelColourLabel[i]);
			pSel[i].add(pSelColour[i]);
		}
	
		centrePanel.add(pSel[0]);
		centrePanel.add(pSel[1]);
		centrePanel.add(pSel[2]);
		centrePanel.add(pSel[3]);
		
		//pScore.setBackground(orange);
		
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel, BorderLayout.NORTH);
		getContentPane().add(centrePanel, BorderLayout.CENTER);
		getContentPane().add(bottomPanel, BorderLayout.SOUTH);		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
		//int test = pAmount.SelectedIndex;
		//System.out.println(test);
	}
	
	public void actionPerformed (ActionEvent aevt){		
		Object selected = aevt.getSource();
		Color cyan = new Color(0,240,240);
		Color red = new Color(255,0,0);
		if ( selected instanceof JRadioButton){
			int HumanIn = Arrays.asList(pSelTypeHuman).indexOf(selected);
			int CpuIn = Arrays.asList(pSelTypeCpu).indexOf(selected);
			if(HumanIn !=-1){
				if(pSelTypeHuman[HumanIn].isSelected()){
					pSelTypeCpu[HumanIn].setSelected(false);
					pSelMiddlePanel[HumanIn].removeAll();
					
					pSelMiddlePanel[HumanIn].add(pSelNameLabel[HumanIn]);
					pSelMiddlePanel[HumanIn].add(pSelName[HumanIn]);
					pSelName[HumanIn].setText("Player"+String.valueOf(HumanIn+1));
					
					pSelMiddlePanel[HumanIn].validate();
				}
				else pSelTypeHuman[HumanIn].setSelected(true);
			}
			if(CpuIn != -1){
				if(pSelTypeCpu[CpuIn].isSelected()){
					pSelTypeHuman[CpuIn].setSelected(false);
					pSelMiddlePanel[CpuIn].removeAll();
					
					pSelName[CpuIn].setText("Computer"+String.valueOf(CpuIn+1));
					pSelMiddlePanel[CpuIn].add(pSelCpuLabel[CpuIn]);
					pSelMiddlePanel[CpuIn].add(pSelCpuDif[CpuIn]);
					
					pSelCpuDif[CpuIn].setSelectedIndex(1);
					pSelMiddlePanel[CpuIn].validate();
					
				}
				else pSelTypeCpu[CpuIn].setSelected(true);
			}
		}
		if ( selected.equals(pAmount)){
			int players = pAmount.getSelectedIndex()+2;
			//System.out.println(players);
			centrePanel.removeAll();
			for(int i = 0;i<players;i++){
				centrePanel.add(pSel[i]);
			}
			if(players == 3)
				pSelColour[3].setSelectedIndex(0);
			centrePanel.validate();
			
		}		
		if ( selected.equals(startGame)){
			Random rand = new Random();
			boolean valid = true;
			String error = "";
			int[] avaCol = {0,0,0,0,0};
			int[] pColour = new int[4];
			String[] names = new String[4];
			int[] dif = new int[4];
			for(int i=0;i<4;i++){
				pColour[i] = pSelColour[i].getSelectedIndex();
				avaCol[pColour[i]]++;
				names[i] = pSelName[i].getText();
				if(!names[i].matches("[a-zA-Z0-9]*")){
					valid = false;
					error = "Names must contain only letters or numbers";
				}
				if(pSelTypeHuman[i].isSelected()){
					dif[i] = -1;
				}
				else{
					dif[i] = pSelCpuDif[i].getSelectedIndex();
				}
					
			}
			if(avaCol[1]>1||avaCol[2]>1||avaCol[3]>1||avaCol[4]>1){
				valid = false;
				error = "Two players can not be same colour selected";
			}
			else{
				for(int colour = 1;colour<=4;colour++){
					//System.out.println(avaCol[colour]+"avaCol");
					if(avaCol[colour] == 0){
						
						int next = rand.nextInt(avaCol[0]);
						int count = 0;
						System.out.println("rand"+next);
						for(int x=0;x<4;x++){
							//System.out.println(pColour[x]+"pcolour"+count);
							if(pColour[x]==0){
								if(count == next){
									pColour[x]=colour;
									avaCol[0]--;
								}
								count++;
							}
						}
					}
				}
				for(int x=0;x<4;x++){
					pColour[x]--;
					//System.out.println(pColour[x]);
				}
			}
			
			if(valid){
				String[] players = new String[pAmount.getSelectedIndex()+2];
				for(int pNum=0;pNum<pAmount.getSelectedIndex()+2;pNum++){
					players[pNum]=pSelName[pNum].getText();
				}
				Game game = new Game(saveName.getText(),players,dif,pColour,cBlindMode.isSelected());
				GameGui newGame = new GameGui(game);
				dispose();
			}
			else{
				bottomPanel.removeAll();
				errorMessage = new JLabel(error);
				bottomPanel.add(errorMessage);
				bottomPanel.add(startGame);
				bottomPanel.validate();
			}
		}
		
		if ( selected.equals(pSelColour[0])) {}
		
	}	
}
