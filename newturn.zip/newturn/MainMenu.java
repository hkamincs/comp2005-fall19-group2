package newturn;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

@SuppressWarnings("unchecked")
public class MainMenu extends JFrame implements ActionListener{
	private JLabel title;
	private JButton newGame, loadGame, exitGame;
	
	public MainMenu(){
		this.setSize(1000,600);
		title = new JLabel("BLOKUS");
		newGame = new JButton("New Game");
		loadGame = new JButton("Load Game");
		exitGame = new JButton("Exit");
		newGame.addActionListener(this);
		loadGame.addActionListener(this);
		exitGame.addActionListener(this);
		getContentPane().setLayout(new BoxLayout(getContentPane(),BoxLayout.Y_AXIS));
		getContentPane().add(title);
		getContentPane().add(newGame);
		getContentPane().add(loadGame);
		getContentPane().add(exitGame);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
		
	}
	
	public void actionPerformed (ActionEvent aevt){		
		Object selected = aevt.getSource();
		if ( selected instanceof JButton){
			if(selected.equals(newGame)){
				SetupGame game = new SetupGame();
				dispose();
			}
			if(selected.equals(loadGame)){
				
			}
			if(selected.equals(exitGame)){
				dispose();
			}
		}
	}	
}
