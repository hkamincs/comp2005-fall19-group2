package newturn;


/**
 * Write a description of class Main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class main
{
    // instance variables - replace the example below with your own
    public static void main(String[] args)
    {
        MainMenu game = new MainMenu();
    }

    
}
