package newturn;
import java.awt.Color;
import javax.swing.*;

/**
 * Write a description of class GridButton here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GridButton extends JButton
{
    // instance variables - replace the example below with your own
    private int xcoord, ycoord;
	private static int playerNum = 1;
	private int tileNum;
	private int orientation;
    
    
    /**
     * Constructor for objects of class GridButton
     */
    public GridButton(int x, int y)
    {
        // initialise instance variables
        //super();
        xcoord = x;
        ycoord = y;
        //playerNum = 1; //stand in value for demo purpose
        tileNum = 1; //stand in value for demo purpose
        orientation = 1;//starting orientation
        
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int getXCoord()
    {
        // put your code here
        return xcoord;
    }
    public static int getPlayerNum()
    {
        return playerNum;
    }
    public static void nextPlayerNum()
    {
    	playerNum ++;
    }
    public static void resetPlayerNum()
    {
    	playerNum = 1;
    }
    public int getYCoord()
    {
        return ycoord;
    }
    public void setTileNum(int x)
    {
        tileNum = x;
    }
    public int getTileNum()
    {
        return tileNum;
    }
    public void addOrientation(int x)
    {
        orientation+=x;
    }
    public void minusOrientation()
    {
        orientation--;
    }
    public int getOrientation()
    {
        return orientation;
    }
    public void subOrientation(int x)
    {
        orientation-=x;
    }
    public void incrOrientation()
    {
        orientation++;
    }
    public void setOrientation(int x)
    {
        orientation = x;
    }
    public void setColour()
    {
        if (playerNum == 1)
        {
            this.setBackground(Color.BLUE);
        }
        if (playerNum == 2)
        {
            this.setBackground(Color.GREEN);
        }
        if (playerNum == 3)
        {
            this.setBackground(Color.RED);
        }
        if (playerNum == 4)
        {
            this.setBackground(Color.YELLOW);
        }
    }
}