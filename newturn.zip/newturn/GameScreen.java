package newturn;
import java.awt.*;
import java.awt.List;
import java.awt.event.*;
import java.lang.reflect.Array;

import javax.swing.*;
import java.math.*;
import java.util.*;
/**
 * Write a description of class GameScreen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GameScreen extends JFrame implements ActionListener
{
    // instance variables - replace the example below with your own
    private JPanel topPanel, bottomPanel;
    
    private JButton leftButton, resetButton, flipButton, rightButton, confirmButton;
    private GridButton [][] gridButtons;
    private int x, y, countOfButtons;
    public static int[][] arr = {};

    /**
     * Constructor for objects of class GameScreen
     */
    public GameScreen()
    {
        // initialise instance variables
        x = 0;
        y = 0;
        countOfButtons = 0;
        topPanel = new JPanel();
        bottomPanel = new JPanel();
        bottomPanel.setLayout( new FlowLayout());
        leftButton = new JButton("Left");
        leftButton.addActionListener( this);
        resetButton = new JButton("Reset");
        resetButton.addActionListener( this);
        flipButton = new JButton("Flip");
        flipButton.addActionListener( this);
        rightButton = new JButton("Right");
        rightButton.addActionListener( this);
        confirmButton = new JButton("comfirm");
        confirmButton.addActionListener( this);
        bottomPanel.add( leftButton);
        bottomPanel.add( resetButton);
        bottomPanel.add( flipButton);
        bottomPanel.add( rightButton);
        bottomPanel.add( confirmButton);
        bottomPanel.setPreferredSize(new Dimension(400, 70));
        topPanel.setPreferredSize(new Dimension(400, 300));
        topPanel.setLayout( new GridLayout( 5, 5));
        gridButtons = new GridButton [5][5];
        for ( int column = 0; column < 5; column ++)
            {
                for ( int row = 0; row < 5; row ++)
        {
            gridButtons [column][row] = new GridButton( column,row);
            //gridButtons [column][row].setSize( 50, 50);
            gridButtons [column][row].setOpaque( true);
            
            gridButtons [column][row].addActionListener( this);
            topPanel.add( gridButtons [column][row]);
        }
            }
            setVisible(true);
        updateOri();
        getContentPane().setLayout( new BorderLayout());
        getContentPane().add( topPanel, BorderLayout.NORTH);
        getContentPane().add( bottomPanel, BorderLayout.SOUTH);
        pack();
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        setResizable( true);
        setVisible( true);
    }

    public void updateOri()
    {
        int ori = gridButtons [0][0].getOrientation();
        
        if (ori == 1)
            {
        	int[][] arr1 = {{0,0}, {0,1}, {1,1}, {2,1}, {1,2}};
        	arr = arr1;
        	for (int a = 0; a < 5; a++) {
        		int A = arr1[a][0];
        		int B = arr1[a][1];
        		gridButtons [A][B].setColour();
        	}
            /*gridButtons [0][0].setColour();
            gridButtons [0][1].setColour();
            gridButtons [1][1].setColour();
            gridButtons [2][1].setColour();
            gridButtons [1][2].setColour();*/
            }
            else if (ori == 2)
            {
            	int[][] arr1 = {{0,1}, {1,0}, {1,1}, {2,0}, {1,2}};
            	arr = arr1;
            	for (int a = 0; a < 5; a++) {
            		int A = arr1[a][0];
            		int B = arr1[a][1];
            		gridButtons [A][B].setColour();
            	}
                /*gridButtons [0][1].setColour();
                gridButtons [1][0].setColour();
                gridButtons [1][1].setColour();
                gridButtons [2][0].setColour();
                gridButtons [1][2].setColour();**/
            }
            else if (ori == 3)
            {
            	int[][] arr1 = {{1,0}, {0,1}, {1,1}, {2,1}, {2,2}};
            	arr = arr1;
            	for (int a = 0; a < 5; a++) {
            		int A = arr1[a][0];
            		int B = arr1[a][1];
            		gridButtons [A][B].setColour();
            	}
               /* gridButtons [1][0].setColour();
                gridButtons [0][1].setColour();
                gridButtons [1][1].setColour();
                gridButtons [2][1].setColour();
                gridButtons [2][2].setColour();**/
            }
            else if (ori == 4)
            {
            	int[][] arr1 = {{0,2}, {1,0}, {1,1}, {2,1}, {1,2}};
            	arr = arr1;
            	for (int a = 0; a < 5; a++) {
            		int A = arr1[a][0];
            		int B = arr1[a][1];
            		gridButtons [A][B].setColour();
            	}
                /*gridButtons [0][2].setColour();
        gridButtons [1][0].setColour();
        gridButtons [1][1].setColour();
        gridButtons [2][1].setColour();
        gridButtons [1][2].setColour();**/
            }
            else if (ori == 5)
            {
            	int[][] arr1 = {{0,2}, {0,1}, {1,1}, {1,0}, {2,1}};
            	arr = arr1;
            	for (int a = 0; a < 5; a++) {
            		int A = arr1[a][0];
            		int B = arr1[a][1];
            		gridButtons [A][B].setColour();
            	}
                /*gridButtons [0][2].setColour();
                gridButtons [0][1].setColour();
                gridButtons [1][1].setColour();
                gridButtons [1][0].setColour();
                gridButtons [2][1].setColour();*/
            }
            else if (ori == 6)
            {
            	int[][] arr1 = {{0,0}, {1,0}, {1,1}, {2,1}, {1,2}};
            	arr = arr1;
            	for (int a = 0; a < 5; a++) {
            		int A = arr1[a][0];
            		int B = arr1[a][1];
            		gridButtons [A][B].setColour();
            	}
            }
                /*gridButtons [0][0].setColour();
                gridButtons [1][0].setColour();
                gridButtons [1][1].setColour();
                gridButtons [2][1].setColour();
                gridButtons [1][2].setColour();*/
            else if (ori == 7)
            {
            	int[][] arr1 = {{2,0}, {0,1}, {1,1}, {2,1}, {1,2}};
            	arr = arr1;
            	for (int a = 0; a < 5; a++) {
            		int A = arr1[a][0];
            		int B = arr1[a][1];
            		gridButtons [A][B].setColour();
            	}
            }
                /*gridButtons [2][0].setColour();
                gridButtons [0][1].setColour();
                gridButtons [1][1].setColour();
                gridButtons [2][1].setColour();
                gridButtons [1][2].setColour();*/
            else if (ori == 8)
            {
            	int[][] arr1 = {{2,2}, {0,1}, {1,1}, {1,0}, {1,2}};
            	arr = arr1;
            	for (int a = 0; a < 5; a++) {
            		int A = arr1[a][0];
            		int B = arr1[a][1];
            		gridButtons [A][B].setColour();
            	}}
            }
        /*gridButtons [2][2].setColour();
        gridButtons [0][1].setColour();
        gridButtons [1][1].setColour();
        gridButtons [1][0].setColour();
        gridButtons [1][2].setColour();*/
    public void actionPerformed (ActionEvent aevt)
    {
        Object selected = aevt.getSource();
        
        if (selected.equals(leftButton))
        {
            for ( int column = 0; column < 5; column ++)
            {
                for ( int row = 0; row < 5; row ++)
        {
            int safety = gridButtons [column][row].getOrientation();
            gridButtons [column][row].setBackground(Color.WHITE);
            if (safety == 8)
            {
                gridButtons [column][row].setOrientation(1);
            }
            else
            {
            gridButtons [column][row].incrOrientation();
        }
        }
            }
            updateOri();
            
        }
        if (selected.equals(resetButton))
        {
            for ( int column = 0; column < 5; column ++)
            {
                for ( int row = 0; row < 5; row ++)
        {
            gridButtons [column][row].setOrientation(1);
            gridButtons [column][row].setBackground(Color.WHITE);
        }
        }
        updateOri();
        }
        if (selected.equals(flipButton))
        {
            for ( int column = 0; column < 5; column ++)
            {
                for ( int row = 0; row < 5; row ++)
        {
            int safety = gridButtons [column][row].getOrientation();
            gridButtons [column][row].setBackground(Color.WHITE);
            if (safety < 5)
            {
                gridButtons [column][row].addOrientation(4);
            }
            else
            {
            gridButtons [column][row].subOrientation(4);
        }
        }
        }
        updateOri();
        }
        if (selected.equals(rightButton))
        {
            for ( int column = 0; column < 5; column ++)
            {
                for ( int row = 0; row < 5; row ++)
        {
            int safety = gridButtons [column][row].getOrientation();
            gridButtons [column][row].setBackground(Color.WHITE);
            if (safety == 1)
            {
                gridButtons [column][row].setOrientation(8);
            }
            else
            {
            gridButtons [column][row].minusOrientation();
        }
        }
            }
            updateOri();
            
        }
       if (selected.equals(confirmButton))
       {
    	   leftButton.setEnabled(false);
    	   resetButton.setEnabled(false);
    	   flipButton.setEnabled(false);
    	   rightButton.setEnabled(false);
    	   GameScreen.this.dispose();
       }
    }
}