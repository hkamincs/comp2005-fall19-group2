The boardgame Blokus by Strata games. I made this in one day Fall 2011, just for fun.

Controls:
-    Click a piece on the left to select it
-    Move the mouse over the board to position a piece
-    Scroll to rotate a piece
-    Right-click to flip a piece over
-    Click on the board to place a piece

![IBlokus Screenshot](http://i.imgur.com/spGkoBM.png)