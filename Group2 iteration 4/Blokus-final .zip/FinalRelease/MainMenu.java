import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

@SuppressWarnings("unchecked")
public class MainMenu extends JFrame implements ActionListener{
	private JPanel buttons;
	private JLabel title;
	private JButton newGame, loadGame, exitGame, back, load;
	private JComboBox loadFile;
	
	public MainMenu(){
		this.setSize(1000,600);
		buttons = new JPanel();
		//buttons.setSize(500,300);
		title = new JLabel("BLOKUS");
		newGame = new JButton("New Game");
		loadGame = new JButton("Load Game");
		exitGame = new JButton("Exit");
		back = new JButton("   Back   ");
		load = new JButton("   Start Game   ");
		newGame.addActionListener(this);
		loadGame.addActionListener(this);
		exitGame.addActionListener(this);
		back.addActionListener(this);
		load.addActionListener(this);
		buttons.setLayout(new BoxLayout(buttons,BoxLayout.Y_AXIS));
		getContentPane().setLayout(new BoxLayout(getContentPane(),BoxLayout.Y_AXIS));
		getContentPane().add(title);
		buttons.add(newGame);
		buttons.add(loadGame);
		buttons.add(exitGame);
		getContentPane().add(buttons);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
		//getContentPane().validate();
		
	}
	
	public void actionPerformed (ActionEvent aevt){		
		Object selected = aevt.getSource();
		if ( selected instanceof JButton){
			if(selected.equals(newGame)){
				SetupGame game = new SetupGame();
				dispose();
			}
			if(selected.equals(loadGame)){
				File folder = new File("Save");
				File[] listOfFiles = folder.listFiles();
				//System.out.println(listOfFiles[0].getName()).substring(0,(int)listOfFiles[0].length()-4));
				String[] saveNames = new String[listOfFiles.length+1];
				saveNames[0] = "Select Save File";
				for (int i=0;i<listOfFiles.length;i++){
					String fileName = listOfFiles[i].getName();
					saveNames[i+1] = fileName.substring(0,fileName.length()-4);
					//System.out.println(saveNames[i+1]);
				}
				buttons.removeAll();
				loadFile = new JComboBox(saveNames);
				buttons.add(loadFile);
				buttons.add(load);
				buttons.add(back);
				
				getContentPane().validate();
				
				//buttons.println(saveNames[0]);
			}
			if(selected.equals(exitGame)){
				dispose();
			}
			if(selected.equals(back)){
				buttons.removeAll();
				buttons.add(newGame);
				buttons.add(loadGame);
				buttons.add(exitGame);
				getContentPane().validate();
			}
			if(selected.equals(load)){
				Game savedGame = new Game(String.valueOf(loadFile.getSelectedItem()));
				BlokusBoard newGame = new BlokusBoard();
			    dispose();
			    
			    
			}
		}
	}	
}
